package com.cognizant.test;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

// TODO: Auto-generated Javadoc
/**
 * The Class LearnTodayApplicationTests.
 */
@SpringBootTest
class LearnTodayApplicationTests {

	/**
	 * Context loads.
	 */
	@Test
	void contextLoads() {
	}

}
