package com.cognizant.springlearn.service.exception;

public class EmployeeNotFoundException extends Exception {

	public EmployeeNotFoundException(String string) {
		super(string);
	}

}
